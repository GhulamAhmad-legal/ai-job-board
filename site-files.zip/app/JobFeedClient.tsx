'use client';

import { useState, useRef, useEffect } from 'react';
import type { FormEvent } from 'react';
import Link from 'next/link';

const PAGE_SIZE = 150;

// Salary is only shown when real values exist (stored in thousands).
function hasSalary(job: any) {
  return (
    typeof job.salary_min === 'number' &&
    typeof job.salary_max === 'number' &&
    job.salary_min > 0 &&
    job.salary_max >= job.salary_min
  );
}

// "Remote - United States" / "Remote, US" are fully remote.
// "Remote-Friendly (Travel-Required) | ..." is not.
function isFullyRemote(job: any) {
  if (Array.isArray(job.tags) && job.tags.includes('Remote')) return true;
  return /^remote(\s+-\s+|\s*,\s*)/i.test(job.location ?? '');
}

// Location text for a card. Roles posted in several places show "+N more".
function locationLabel(job: any) {
  const first = (job.location ?? '').split(';')[0];
  return (job.group_size ?? 1) > 1 ? `${first} +${job.group_size - 1} more` : first;
}

interface Props {
  initialJobs: any[];
  totalCount: number;
}

export default function JobFeedClient({ initialJobs, totalCount }: Props) {
  // 🧠 State initialized DIRECTLY with server-rendered jobs
  const [jobs, setJobs] = useState<any[]>(initialJobs);
  const [activeJob, setActiveJob] = useState<any | null>(initialJobs[0] || null);
  
  const [searchTitle, setSearchTitle] = useState('');
  const [searchLocation, setSearchLocation] = useState('');
  const [remoteOnly, setRemoteOnly] = useState(false); 
  const [easyApplyOnly, setEasyApplyOnly] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState('Any time');
  const [selectedRating, setSelectedRating] = useState('Any');
  const [selectedSort, setSelectedSort] = useState('Most recent');
  const [savedJobIds, setSavedJobIds] = useState<number[]>([]);
  
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [alertEmail, setAlertEmail] = useState('');
  const [alertKeywords, setAlertKeywords] = useState('');
  const [alertLocation, setAlertLocation] = useState('');
  const [alertRemote, setAlertRemote] = useState(false);
  const [alertTrap, setAlertTrap] = useState(''); // hidden field; real people leave it empty
  const [alertStatus, setAlertStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [alertError, setAlertError] = useState('');

  // Pagination State (page 0 = newest 150; duplicates of the first screen are skipped)
  const [page, setPage] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [total, setTotal] = useState(totalCount); // total matching roles (changes with filters)
  const [isSearching, setIsSearching] = useState(false);
  const requestId = useRef(0);
  const firstRun = useRef(true);

  const descriptionScrollRef = useRef<HTMLDivElement>(null);

  const handleJobClick = (job: any) => {
    setActiveJob(job);
    if (descriptionScrollRef.current) {
      descriptionScrollRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const toggleSaveJob = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    setSavedJobIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  // Build the API URL for the current filters (search runs in the database, not just on loaded jobs)
  const buildUrl = (pageNum: number) => {
    const p = new URLSearchParams({ page: String(pageNum) });
    if (remoteOnly) p.set('remote', '1');
    if (searchTitle.trim()) p.set('q', searchTitle.trim());
    if (searchLocation.trim()) p.set('loc', searchLocation.trim());
    return `/api/jobs?${p.toString()}`;
  };

  const filtersActive = remoteOnly || searchTitle.trim() !== '' || searchLocation.trim() !== '';

  // When a filter changes: search the whole database (debounced). When all filters clear: restore the start page.
  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    const id = ++requestId.current;

    if (!filtersActive) {
      setJobs(initialJobs);
      setTotal(totalCount);
      setPage(0);
      setHasMore(true);
      setActiveJob(initialJobs[0] || null);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(buildUrl(0));
        if (!res.ok) throw new Error('Search failed');
        const data = await res.json();
        if (id !== requestId.current) return; // a newer search has started
        const results = data.jobs ?? [];
        setJobs(results);
        setTotal(data.total ?? results.length);
        setPage(1);
        setHasMore(results.length >= PAGE_SIZE);
        setActiveJob(results[0] || null);
      } catch {
        // keep the current list if the search fails
      }
      if (id === requestId.current) setIsSearching(false);
    }, 350);

    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remoteOnly, searchTitle, searchLocation]);

  const openAlertModal = () => {
    setAlertKeywords(searchTitle);
    setAlertLocation(searchLocation);
    setAlertRemote(remoteOnly);
    setAlertStatus('idle');
    setAlertError('');
    setShowAlertModal(true);
  };

  const closeAlertModal = () => {
    setShowAlertModal(false);
    setAlertStatus('idle');
    setAlertError('');
  };

  const submitAlert = async (e: FormEvent) => {
    e.preventDefault();
    setAlertStatus('sending');
    setAlertError('');
    try {
      const res = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: alertEmail,
          keywords: alertKeywords,
          location: alertLocation,
          remoteOnly: alertRemote,
          website: alertTrap,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setAlertStatus('error');
        setAlertError(data.error || 'Something went wrong. Please try again.');
        return;
      }
      setAlertStatus('done');
    } catch {
      setAlertStatus('error');
      setAlertError('Network problem. Please try again.');
    }
  };

  // Load More (uses the same filters, skips jobs already on screen)
  const loadMoreJobs = async () => {
    setIsLoadingMore(true);
    try {
      const res = await fetch(buildUrl(page));
      if (!res.ok) throw new Error('Failed to load jobs');
      const { jobs: more = [] } = await res.json();

      setJobs(prev => {
        const seen = new Set(prev.map((j: any) => j.id));
        return [...prev, ...more.filter((j: any) => !seen.has(j.id))];
      });
      setPage(prev => prev + 1);
      if (more.length < PAGE_SIZE) setHasMore(false);
    } catch {
      // Leave the button available so the user can retry.
    }
    setIsLoadingMore(false);
  };

  const filteredJobs = jobs.filter(job => {
    const matchesTitle = searchTitle === '' ? true : (
      job.title.toLowerCase().includes(searchTitle.toLowerCase()) || 
      job.company.toLowerCase().includes(searchTitle.toLowerCase()) ||
      (job.description && job.description.toLowerCase().includes(searchTitle.toLowerCase()))
    );
    const loc = (job.location ?? '').toLowerCase();
    const matchesLocation = searchLocation === '' ? true : loc.includes(searchLocation.toLowerCase());
    const matchesRemote = remoteOnly ? isFullyRemote(job) : true;

    let matchesDate = true;
    if (selectedDate !== 'Any time' && job.created_at) {
      const jobDate = new Date(job.created_at);
      const diffDays = (new Date().getTime() - jobDate.getTime()) / (1000 * 3600 * 24);
      if (selectedDate === 'Last day') matchesDate = diffDays <= 1;
      if (selectedDate === 'Last 3 days') matchesDate = diffDays <= 3;
      if (selectedDate === 'Last week') matchesDate = diffDays <= 7;
      if (selectedDate === 'Last 2 weeks') matchesDate = diffDays <= 14;
      if (selectedDate === 'Last month') matchesDate = diffDays <= 30;
    }

    return matchesTitle && matchesLocation && matchesRemote && matchesDate;
  });

  return (
    <main className="min-h-screen flex flex-col bg-[#F5F6F8] text-[#181818] font-sans w-full">
      <section className="relative bg-white pt-20 pb-12 lg:pt-24 lg:pb-16 border-b border-gray-200 shadow-sm z-40 shrink-0 overflow-visible">
        <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80">
          <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"></div>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-6xl mb-6">
            Find your next role in <br className="hidden sm:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Artificial Intelligence</span>
          </h1>
          <p className="mx-auto max-w-2xl text-[17px] leading-8 text-gray-500 mb-10 font-medium">
            Browse {totalCount.toLocaleString()} active roles at leading AI and tech companies.
          </p>

          <div className="mx-auto max-w-4xl flex flex-col md:flex-row items-center bg-white rounded-3xl md:rounded-full p-2 shadow-xl shadow-gray-200/50 ring-1 ring-gray-200 focus-within:ring-2 focus-within:ring-indigo-600 transition-all mb-8">
            <div className="flex-1 flex items-center px-4 w-full border-r border-gray-200">
              <input type="text" placeholder="Search by role, keywords..." className="w-full border-none focus:ring-0 text-[15px] py-3 outline-none bg-transparent" value={searchTitle} onChange={(e) => setSearchTitle(e.target.value)} />
            </div>
            <div className="flex-1 flex items-center px-4 w-full">
              <input type="text" placeholder="City, state, or 'remote'" className="w-full border-none focus:ring-0 text-[15px] py-3 outline-none bg-transparent" value={searchLocation} onChange={(e) => setSearchLocation(e.target.value)} />
            </div>
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 px-8 rounded-full shadow-md w-full md:w-auto">Search Jobs</button>
          </div>
          
          <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-3">
             <div className="flex flex-wrap items-center gap-3">

               <button onClick={() => setRemoteOnly(!remoteOnly)} className={`px-5 py-2 text-[13px] font-bold rounded-full border transition-all ${remoteOnly ? 'bg-indigo-50 text-indigo-700 border-indigo-500' : 'bg-white text-gray-600 border-gray-300'}`}>Remote only</button>
             </div>
             
             {/* Job Alert Button */}
             <button onClick={openAlertModal} className="flex items-center gap-2 text-indigo-600 font-bold text-[14px] hover:text-indigo-800 transition-colors">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                Create Job Alert
             </button>
          </div>
        </div>
      </section>

      <div className="flex-1 max-w-[1152px] w-full mx-auto px-4 flex items-start gap-5 py-6">
        {/* Left Column Feed */}
        <div className="w-full lg:w-[420px] flex flex-col shrink-0">
          <div className="mb-4 flex items-center justify-between shrink-0">
            <span className="text-[14px] font-bold text-gray-500">
              {isSearching
                ? 'Searching...'
                : filteredJobs.length === jobs.length
                  ? `Showing ${jobs.length} of ${total.toLocaleString()} roles`
                  : `${filteredJobs.length} roles found`}
            </span>
          </div>
          
          <div className="flex flex-col pb-6">
            {filteredJobs.map((job) => (
              <Link
                key={job.id}
                href={`/job/${job.id}`}
                onClick={(e) => {
                  // Desktop: preview in the side panel. Mobile: open the job page.
                  if (window.matchMedia('(min-width: 1024px)').matches) {
                    e.preventDefault();
                    handleJobClick(job);
                  }
                }}
                className={`block p-5 mb-4 cursor-pointer border rounded-2xl ${activeJob?.id === job.id ? 'bg-indigo-50/50 border-indigo-300 shadow-md border-l-4 border-l-indigo-600' : 'bg-white border-gray-200 hover:shadow-xl hover:border-indigo-500'}`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-[36px] h-[36px] border border-gray-200 rounded-lg flex items-center justify-center font-black text-[12px] overflow-hidden bg-white">
                    {job.company_logo_url ? <img src={job.company_logo_url} className="w-full h-full object-contain p-0.5" alt={job.company} /> : job.company.slice(0, 2).toUpperCase()}
                  </div>
                  <span className="text-[14px] font-bold text-gray-900">{job.company}</span>
                </div>
                <h2 className="text-[17px] font-extrabold mb-3 text-gray-900">{job.title}</h2>
                <div className="flex gap-2">
                  <span className="rounded-full bg-indigo-50 px-2.5 py-1 text-[11px] font-bold text-indigo-700 border border-indigo-200 truncate">{locationLabel(job)}</span>
                  {hasSalary(job) && (
                    <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-700 border border-emerald-200">${job.salary_min}K – ${job.salary_max}K</span>
                  )}
                </div>
              </Link>
            ))}
          </div>

          {/* Load More Button */}
          {hasMore && jobs.length < total && (
            <div className="pb-10 flex justify-center">
              <button 
                onClick={loadMoreJobs} 
                disabled={isLoadingMore}
                className="bg-white border border-gray-200 text-gray-700 hover:text-indigo-600 hover:border-indigo-600 font-bold py-3 px-8 rounded-xl shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoadingMore ? 'Loading...' : 'Load More Jobs'}
              </button>
            </div>
          )}
        </div>

        {/* Right Column Sticky Details */}
        <div className="hidden lg:block flex-1 min-w-0 sticky top-6 h-[calc(100vh-48px)]">
          <div ref={descriptionScrollRef} className="h-full overflow-y-auto pr-2 pb-10">
            {activeJob && (
              <div className="bg-white border border-gray-200 rounded-2xl shadow-sm flex flex-col">
               <div className="px-8 py-8 border-b border-gray-100 bg-white rounded-t-2xl">
                 {/* Logo and Company Name */}
                 <div className="flex items-center gap-4 mb-5">
                   <div className="w-[56px] h-[56px] border border-gray-200 rounded-xl flex items-center justify-center font-black text-[16px] overflow-hidden bg-white shadow-sm">
                     {activeJob.company_logo_url ? (
                       <img src={activeJob.company_logo_url} className="w-full h-full object-contain p-1" alt={activeJob.company} />
                     ) : (
                       activeJob.company.slice(0, 2).toUpperCase()
                     )}
                   </div>
                   <span className="text-[20px] font-bold text-gray-900">{activeJob.company}</span>
                 </div>

                 {/* Job Title */}
                 <h2 className="text-[28px] md:text-[32px] font-extrabold text-gray-900 mb-5 leading-tight tracking-tight">
                   {activeJob.title}
                 </h2>

                 {/* Location and Salary Pills */}
                 <div className="flex flex-wrap items-center gap-3 mb-8">
                   <span className="bg-gray-50 text-gray-700 px-4 py-2 rounded-lg text-[14px] font-bold border border-gray-200">
                     {locationLabel(activeJob)}
                   </span>
                   {hasSalary(activeJob) && (
                     <span className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-lg text-[14px] font-bold border border-emerald-200">
                       ${activeJob.salary_min}K – ${activeJob.salary_max}K <span className="font-medium opacity-80">/yr</span>
                     </span>
                   )}
                 </div>

                 {/* Apply Button */}
                 {activeJob.apply_url && (
                   <a href={activeJob.apply_url} target="_blank" rel="noopener noreferrer nofollow" className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[15px] px-8 py-3.5 rounded-xl shadow-sm transition-all hover:-translate-y-0.5">
                     Apply on employer site
                   </a>
                 )}
               </div>
               <div className="p-8 pb-16 prose max-w-none" dangerouslySetInnerHTML={{ __html: activeJob.description ?? '' }} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Job Alert Modal */}
      {showAlertModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl relative max-h-[92vh] overflow-y-auto">
            <button onClick={closeAlertModal} aria-label="Close" className="absolute top-5 right-5 text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {alertStatus !== 'done' ? (
              <>
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-5">
                  <svg className="w-6 h-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </div>
                <h3 className="text-2xl font-extrabold text-gray-900 mb-2">Get an email when new roles match</h3>
                <p className="text-gray-500 mb-6 text-[15px]">
                  Tell us what you are looking for. We will email you new matching jobs, at most once a day, and only
                  after you confirm your address.
                </p>

                <form onSubmit={submitAlert} className="flex flex-col gap-4">
                  <label className="text-[13px] font-bold text-gray-700">
                    Email
                    <input
                      type="email"
                      required
                      maxLength={254}
                      autoComplete="email"
                      placeholder="you@example.com"
                      className="mt-1 w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all text-[15px] font-normal"
                      value={alertEmail}
                      onChange={(e) => setAlertEmail(e.target.value)}
                    />
                  </label>
                  <label className="text-[13px] font-bold text-gray-700">
                    Keywords <span className="font-normal text-gray-400">(optional)</span>
                    <input
                      type="text"
                      maxLength={80}
                      placeholder="e.g. machine learning engineer"
                      className="mt-1 w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all text-[15px] font-normal"
                      value={alertKeywords}
                      onChange={(e) => setAlertKeywords(e.target.value)}
                    />
                  </label>
                  <label className="text-[13px] font-bold text-gray-700">
                    Location <span className="font-normal text-gray-400">(optional)</span>
                    <input
                      type="text"
                      maxLength={60}
                      placeholder="e.g. London"
                      className="mt-1 w-full border border-gray-300 rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all text-[15px] font-normal"
                      value={alertLocation}
                      onChange={(e) => setAlertLocation(e.target.value)}
                    />
                  </label>
                  <label className="flex items-center gap-2 text-[14px] font-bold text-gray-700">
                    <input
                      type="checkbox"
                      checked={alertRemote}
                      onChange={(e) => setAlertRemote(e.target.checked)}
                      className="w-4 h-4 accent-indigo-600"
                    />
                    Fully remote roles only
                  </label>

                  {/* Spam trap: hidden from people, filled in by bots */}
                  <input
                    type="text"
                    name="website"
                    tabIndex={-1}
                    autoComplete="off"
                    aria-hidden="true"
                    className="hidden"
                    value={alertTrap}
                    onChange={(e) => setAlertTrap(e.target.value)}
                  />

                  {alertStatus === 'error' && (
                    <p role="alert" className="text-[14px] font-bold text-red-600">{alertError}</p>
                  )}

                  <button
                    type="submit"
                    disabled={alertStatus === 'sending'}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-bold py-3.5 rounded-xl shadow-md transition-all"
                  >
                    {alertStatus === 'sending' ? 'Sending…' : 'Create alert'}
                  </button>
                  <p className="text-[12px] text-gray-400 leading-snug">
                    We use your email only to send these alerts, and every email has an unsubscribe link. See our{' '}
                    <Link href="/privacy" className="underline">Privacy Policy</Link>.
                  </p>
                </form>
              </>
            ) : (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5">
                  <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-2xl font-extrabold text-gray-900 mb-2">Check your inbox</h3>
                <p className="text-gray-500 text-[15px]">
                  We sent a confirmation link to <strong>{alertEmail}</strong>. Your alert starts after you click it. If it
                  is not there in a few minutes, check your spam folder.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}